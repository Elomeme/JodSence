from dotenv import load_dotenv, find_dotenv
from langchain_community.chat_models.tongyi import ChatTongyi
from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import START, END, MessagesState, StateGraph
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langchain.tools import Tool
import time
import os
import re
import json
import random

# 尝试导入SerpAPI，如果失败则提供备选方案
try:
    from langchain_community.utilities import SerpAPIWrapper
    SERPAPI_AVAILABLE = True
except ImportError:
    print("⚠️ SerpAPI不可用，将使用内置知识回答问题")
    SERPAPI_AVAILABLE = False

_ = load_dotenv(find_dotenv())

# 配置API密钥
SERPAPI_API_KEY = os.getenv("SERPAPI_API_KEY")

model = ChatTongyi(
    dashscope_api_key="sk-06ff9325a6014b068671d55b26d979ef",
    streaming=True,
    model_name="qwen-turbo"
)

# 联网搜索功能 - 获取面试题目
def web_search(query: str) -> dict:
    """使用SerpAPI进行网络搜索，返回详细的搜索结果和来源信息"""
    try:
        print(f"[日志] 🔍 网络搜索面试题，关键词：{query}")
        
        if not SERPAPI_AVAILABLE:
            return {
                "success": False,
                "content": "网络搜索功能暂不可用，请检查SerpAPI配置",
                "sources": [],
                "total_results": 0
            }
            
        if not SERPAPI_API_KEY:
            return {
                "success": False,
                "content": "SerpAPI密钥未配置，无法进行网络搜索",
                "sources": [],
                "total_results": 0
            }
            
        search = SerpAPIWrapper()
        # 获取原始搜索结果
        raw_result = search.results(query + " 面试题")
        
        # 解析搜索结果，提取详细信息
        sources = []
        content_parts = []
        
        if "organic_results" in raw_result:
            for i, result in enumerate(raw_result["organic_results"][:8]):  # 限制前8个结果
                source = {
                    "id": i + 1,
                    "title": result.get("title", "未知标题"),
                    "url": result.get("link", ""),
                    "snippet": result.get("snippet", "无摘要"),
                    "displayed_link": result.get("displayed_link", ""),
                    "favicon": result.get("favicon", ""),
                    "position": result.get("position", i + 1)
                }
                sources.append(source)
                content_parts.append(f"[{i+1}] {result.get('title', '')}: {result.get('snippet', '')}")
        
        # 如果有知识图谱结果，也包含进来
        if "knowledge_graph" in raw_result:
            kg = raw_result["knowledge_graph"]
            if "description" in kg:
                content_parts.insert(0, f"知识图谱: {kg['description']}")
        
        content = "\n\n".join(content_parts)
        
        print(f"[日志] ✅ 搜索完成，找到 {len(sources)} 个面试题相关结果")
        
        return {
            "success": True,
            "content": content,
            "sources": sources,
            "total_results": len(sources),
            "query": query
        }
        
    except Exception as e:
        error_msg = f"网络搜索失败: {str(e)}"
        print(f"❌ {error_msg}")
        return {
            "success": False,
            "content": error_msg,
            "sources": [],
            "total_results": 0
        }

# 本地面试题库查询功能
def query_local_interview_questions(query: str) -> dict:
    """查询本地面试题库，返回结构化结果"""
    try:
        print(f"\n[日志] 📚 本地面试题库查询，关键词：{query}")
        
        # 模拟本地面试题库
        interview_questions = {
            "python": [
                "请解释Python中的GIL是什么，它对多线程编程有什么影响？",
                "Python中的装饰器是什么？请给出一个简单的例子。",
                "请描述Python中的列表推导式和生成器表达式的区别。",
                "如何在Python中处理异常？请解释try-except-finally的工作流程。",
                "Python中的深拷贝和浅拷贝有什么区别？"
            ],
            "java": [
                "Java中的接口和抽象类有什么区别？",
                "请解释Java中的垃圾回收机制。",
                "什么是Java中的线程安全？如何实现线程安全？",
                "Java中的HashMap和ConcurrentHashMap有什么区别？",
                "请解释Java中的反射机制及其应用场景。"
            ],
            "前端": [
                "请解释JavaScript中的闭包概念及其应用场景。",
                "React中的虚拟DOM是什么？它有什么优势？",
                "请描述CSS盒模型及其组成部分。",
                "Vue和React的主要区别是什么？",
                "什么是跨域问题？如何解决跨域问题？"
            ],
            "数据库": [
                "请解释SQL中的索引及其工作原理。",
                "什么是数据库事务？请解释ACID属性。",
                "NoSQL和关系型数据库有什么区别？",
                "如何优化一个慢查询SQL语句？",
                "请解释数据库范式及其作用。"
            ],
            "算法": [
                "请解释时间复杂度和空间复杂度的概念。",
                "什么是动态规划？请给出一个应用例子。",
                "请描述快速排序的工作原理及其时间复杂度。",
                "如何判断一个链表是否有环？",
                "请解释二叉树的前序、中序和后序遍历。"
            ],
            "系统设计": [
                "如何设计一个高并发的系统？",
                "微服务架构的优缺点是什么？",
                "如何保证分布式系统的一致性？",
                "请解释CAP定理及其在系统设计中的应用。",
                "如何设计一个可扩展的缓存系统？"
            ],
            "软技能": [
                "请描述一个你曾经解决的技术难题及其解决过程。",
                "如何与团队成员有效沟通和协作？",
                "你如何保持对新技术的学习和更新？",
                "请描述一个你参与的项目，以及你在其中的角色和贡献。",
                "你如何处理工作中的压力和挑战？"
            ]
        }
        
        # 根据查询关键词匹配相关题目
        matched_categories = []
        for category, questions in interview_questions.items():
            if category in query.lower() or any(keyword in query.lower() for keyword in category.lower().split()):
                matched_categories.append(category)
        
        # 如果没有匹配到特定类别，随机选择一个类别
        if not matched_categories:
            matched_categories = random.sample(list(interview_questions.keys()), 2)
        
        # 从匹配的类别中选择问题
        selected_questions = []
        for category in matched_categories:
            selected_questions.extend([(category, q) for q in interview_questions[category]])
        
        # 随机打乱问题顺序
        random.shuffle(selected_questions)
        
        # 构建结果
        if selected_questions:
            content_parts = []
            for i, (category, question) in enumerate(selected_questions[:10], 1):
                content_parts.append(f"[{category}] {question}")
            
            result_content = "\n\n".join(content_parts)
            
            return {
                "success": True,
                "content": f"从本地面试题库中找到以下相关问题：\n\n{result_content}",
                "sources": [{
                    "type": "local",
                    "file_name": "interview_questions_database",
                    "categories": matched_categories,
                    "question_count": len(content_parts)
                }],
                "total_results": len(content_parts)
            }
        else:
            return {
                "success": False,
                "content": "在本地面试题库中未找到相关问题。",
                "sources": [],
                "total_results": 0
            }
            
    except Exception as e:
        error_msg = f"本地面试题库查询失败: {str(e)}"
        print(f"❌ {error_msg}")
        return {
            "success": False,
            "content": error_msg,
            "sources": [],
            "total_results": 0
        }

# 定义工具列表
tools = [
    Tool(
        name="web_search",
        func=web_search,
        description="用于搜索最新的IT面试题目和技术问题。当需要获取特定技术领域的面试题时使用此工具。输入：技术领域关键词"
    ),
    Tool(
        name="query_local_interview_questions", 
        func=query_local_interview_questions,
        description="用于查询本地面试题库中的问题。当需要获取常见IT面试题目时使用此工具。输入：技术领域关键词"
    )
]

# 工具调用函数
def call_tools(query: str, tool_name: str) -> dict:
    """根据工具名称调用相应的工具，返回结构化结果"""
    for tool in tools:
        if tool.name == tool_name:
            return tool.func(query)  # 直接返回字典结果
    return {
        "success": False,
        "content": f"未找到工具: {tool_name}",
        "sources": [],
        "total_results": 0
    }

# 面试状态跟踪
class InterviewState(MessagesState):
    """跟踪面试状态的类"""
    question_count: int = 0  # 已提问的问题数量
    current_topic: str = ""  # 当前面试主题
    asked_questions: list = []  # 已提问的问题列表
    candidate_responses: list = []  # 候选人的回答列表
    interview_feedback: list = []  # 面试官的反馈列表
    interview_complete: bool = False  # 面试是否完成

# 智能工具选择函数
def select_and_call_tool(state):
    """智能选择工具并调用"""
    print(f"[日志] 📊 当前状态: {state}")
    
    # 获取状态信息
    question_count = state.get("question_count", 0)
    current_topic = state.get("current_topic", "")
    asked_questions = state.get("asked_questions", [])
    interview_complete = state.get("interview_complete", False)
    messages = state.get("messages", [])
    
    # 检查是否刚刚生成了问题（避免重复生成）
    if messages and "【面试官】" in messages[-1].content:
        print("[日志] ⏸️ 已生成问题，等待用户回答")
        return state  # 不生成新问题，保持当前状态
    
    # 检查面试是否已完成
    if question_count >= 8 or interview_complete:
        print("[日志] ✅ 面试已完成")
        completion_message = HumanMessage(
            content="【面试官】面试已结束，感谢您的参与！我们会尽快给您反馈。",
            additional_kwargs={"interview_complete": True}
        )
        return {
            "messages": [completion_message],
            "question_count": question_count,
            "current_topic": current_topic,
            "asked_questions": asked_questions,
            "interview_complete": True
        }
    
  # 生成新问题的逻辑（保持原有逻辑）
def evaluate_response(state):
        """评估候选人回答"""
        print(f"[日志] 🔍 评估候选人回答")
        
        # 获取状态信息
        messages = state.get("messages", [])
        question_count = state.get("question_count", 0)
        current_topic = state.get("current_topic", "")
        asked_questions = state.get("asked_questions", [])
        
        # ✅ 关键修改：只评估真实的用户回答
        if not messages:
            print("[日志] ⚠️ 没有消息需要评估")
            return state
        
        last_message = messages[-1]
        
        # 检查最后一条消息是否是用户回答（不是面试官问题）
        if "【面试官】" in last_message.content:
            print("[日志] ⚠️ 最后一条消息是面试官问题，无需评估")
            return state
        
        # 获取用户的真实回答
        candidate_answer = last_message.content
        current_question = asked_questions[-1] if asked_questions else "未知问题"
        
        # 构建评估提示
        evaluation_prompt = f"""
        面试问题：{current_question}
        候选人回答：{candidate_answer}
        
        请对候选人的回答进行专业评估，包括：
        1. 技术准确性
        2. 深度理解
        3. 实践经验
        4. 解决问题能力
        5. 表达能力
        
        给出简洁的评估反馈。
        """
        
        # 生成评估
        prompt = ChatPromptTemplate.from_messages([
            ("system", "你是专业的IT技术面试官，请对候选人的回答进行客观评估。"),
            ("human", evaluation_prompt)
        ])
        
        response = model.invoke(prompt.format_messages())
        
        # 返回评估结果
        return {
            "messages": [response],
            "question_count": question_count,
            "current_topic": current_topic,
            "asked_questions": asked_questions,
            "interview_complete": question_count >= 8
        }
        # 在文件末尾添加


def analyze_resume(state):
    """分析用户简历并生成第一个问题"""
    print(f"[日志] 📄 分析用户简历")
    
    messages = state.get("messages", [])
    if not messages:
        return state
    
    # 获取用户输入的简历内容
    user_input = messages[-1].content
    
    # 重新创建分析提示词，确保没有隐藏字符
    analysis_text = "请分析以下简历内容，并根据简历信息生成一个面试问题：\n\n"
    analysis_text += f"简历内容：\n{user_input}\n\n"
    analysis_text += "请：\n"
    analysis_text += "1. 分析候选人的技术背景和经验\n"
    analysis_text += "2. 识别关键技能和项目经验\n"
    analysis_text += "3. 生成一个针对性的开场面试问题\n"
    analysis_text += "4. 问题应该基于简历内容，具有针对性\n\n"
    analysis_text += "直接输出面试问题，格式：【面试官】问题内容"
    
    prompt = ChatPromptTemplate.from_messages([
        ("system", "你是专业的IT技术面试官，擅长根据简历内容提出针对性问题。"),
        ("human", analysis_text)
    ])
    
    response = model.invoke(prompt.format_messages())
    
    return {
        "messages": [response],
        "resume_content": user_input,
        "resume_analyzed": True,
        "question_count": 1,
        "current_topic": "简历相关",
        "asked_questions": [response.content],
        "candidate_responses": [],
        "interview_feedback": [],
        "interview_complete": False
    }

def generate_next_question(state):
    """根据简历、题库和用户回答生成下一个问题"""
    print(f"[日志] 🤔 生成下一个问题")
    
    # 获取状态信息
    messages = state.get("messages", [])
    resume_content = state.get("resume_content", "")
    question_count = state.get("question_count", 0)
    asked_questions = state.get("asked_questions", [])
    candidate_responses = state.get("candidate_responses", [])
    
    # 检查是否已完成面试
    if question_count >= 8:
        completion_message = AIMessage(
            content="【面试官】面试已结束，感谢您的参与！我们会尽快给您反馈。"
        )
        return {
            "messages": [completion_message],
            "resume_content": resume_content,
            "resume_analyzed": True,
            "question_count": question_count,
            "current_topic": state.get("current_topic", ""),
            "asked_questions": asked_questions,
            "candidate_responses": candidate_responses,
            "interview_feedback": state.get("interview_feedback", []),
            "interview_complete": True
        }
    
    # 获取最新的用户回答
    if messages:
        latest_response = messages[-1].content
        candidate_responses.append(latest_response)
    
    # 生成下一个问题
    question_prompt = f"""
    基于以下信息生成下一个面试问题：
    
    简历内容：
    {resume_content}
    
    已提问的问题：
    {chr(10).join([f"{i+1}. {q}" for i, q in enumerate(asked_questions)])}
    
    候选人的回答：
    {chr(10).join([f"{i+1}. {r}" for i, r in enumerate(candidate_responses)])}
    
    请生成第{question_count + 1}个问题，要求：
    1. 基于简历内容和之前的回答
    2. 逐步深入技术细节
    3. 避免重复之前的问题
    4. 问题应该有针对性和挑战性
    
    请直接输出面试问题，格式：【面试官】问题内容
    """
    
    prompt = ChatPromptTemplate.from_messages([
        ("system", "你是专业的IT技术面试官，根据简历和回答历史生成深入的技术问题。"),
        ("human", question_prompt)
    ])
    
    response = model.invoke(prompt.format_messages())
    
    # 更新状态
    new_asked_questions = asked_questions + [response.content]
    
    return {
        "messages": [response],
        "resume_content": resume_content,
        "resume_analyzed": True,
        "question_count": question_count + 1,
        "current_topic": "技术深入",
        "asked_questions": new_asked_questions,
        "candidate_responses": candidate_responses,
        "interview_feedback": state.get("interview_feedback", []),
        "interview_complete": False
    }

def route_workflow(state):
    """路由决定下一步流程"""
    resume_analyzed = state.get("resume_analyzed", False)
    interview_complete = state.get("interview_complete", False)
    messages = state.get("messages", [])
    
    # 如果面试完成，结束
    if interview_complete:
        return "END"
    
    # 如果简历未分析，分析简历
    if not resume_analyzed:
        return "analyze_resume"
    
    # 如果最后一条消息是面试官问题，等待用户回答
    if messages and "【面试官】" in messages[-1].content:
        return "END"  # 等待用户输入
    
    # 否则生成下一个问题
    return "generate_question"
# 修改工作流定义
workflow = StateGraph(state_schema=InterviewState)

# 添加节点
workflow.add_node("analyze_resume", analyze_resume)  # 分析简历节点
workflow.add_node("generate_question", generate_next_question)  # 生成问题节点

# 设置工作流边
workflow.add_edge(START, "analyze_resume")

# 添加条件边
workflow.add_conditional_edges(
    "analyze_resume",
    route_workflow,
    {
        "generate_question": "generate_question",
        "END": END
    }
)

workflow.add_conditional_edges(
    "generate_question",
    route_workflow,
    {
        "analyze_resume": "analyze_resume",
        "generate_question": "generate_question",
        "END": END
    }
)

# 编译工作流
memory = MemorySaver()
app = workflow.compile(checkpointer=memory)

# 添加config配置
config = {
    "configurable": {
        "session_id": time.time(),
        "thread_id": time.time()
    }
}
